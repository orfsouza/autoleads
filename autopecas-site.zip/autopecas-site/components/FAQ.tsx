"use client";

import { useState } from "react";

const faqs = [
  {
    q: "É gratuito procurar uma peça?",
    a: "Sim. Buscar sua peça não custa nada.",
  },
  {
    q: "Preciso criar conta para procurar uma peça?",
    a: "Não precisa. É rápido e simples.",
  },
  {
    q: "Como as lojas entram em contato comigo?",
    a: "Elas te chamam pelo contato que você informar no pedido.",
  },
  {
    q: "Quanto tempo leva para receber uma resposta?",
    a: "Depende das lojas, mas o pedido chega até elas na hora.",
  },
  {
    q: "E se nenhuma loja tiver a peça?",
    a: "Você não paga nada e pode tentar novamente quando quiser.",
  },
  {
    q: "Como funciona para as autopeças?",
    a: "A loja se cadastra e passa a receber pedidos de peças que ela pode ter em estoque.",
  },
  {
    q: "Tem custo para a loja se cadastrar?",
    a: "Isso você confirma direto com a nossa equipe no cadastro.",
  },
  {
    q: "Meus dados ficam seguros?",
    a: "Sim. Usamos seus dados só para conectar você às lojas certas.",
  },
  {
    q: "Posso pedir mais de uma peça?",
    a: "Pode sim, é só fazer um pedido para cada peça.",
  },
  {
    q: "Funciona para qualquer tipo de carro?",
    a: "Sim, para carros, peças e modelos variados.",
  },
  {
    q: "Preciso saber o nome técnico da peça?",
    a: "Não. Descreva do seu jeito, as lojas te ajudam a identificar.",
  },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section className="border-t hairline bg-surface py-24 px-6 md:px-10">
      <div className="mx-auto max-w-3xl">
        <p className="eyebrow mb-4">perguntas frequentes</p>
        <h2 className="font-display font-semibold uppercase text-3xl sm:text-4xl md:text-5xl">
          Ficou com alguma dúvida?
        </h2>

        <div className="mt-12 divide-y hairline border-t border-b hairline">
          {faqs.map((item, i) => {
            const isOpen = open === i;
            return (
              <div key={item.q}>
                <button
                  onClick={() => setOpen(isOpen ? null : i)}
                  aria-expanded={isOpen}
                  className="flex w-full items-center justify-between gap-4 py-5 text-left"
                >
                  <span className="font-display text-base font-medium uppercase tracking-wide text-paper sm:text-lg">
                    {item.q}
                  </span>
                  <span
                    className={`font-mono text-xl text-gold transition-transform ${
                      isOpen ? "rotate-45" : ""
                    }`}
                  >
                    +
                  </span>
                </button>
                <div
                  className={`grid transition-all duration-300 ease-out ${
                    isOpen ? "grid-rows-[1fr] pb-6 opacity-100" : "grid-rows-[0fr] opacity-0"
                  }`}
                  style={{ display: "grid" }}
                >
                  <div className="overflow-hidden">
                    <p className="max-w-xl text-steel">{item.a}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
