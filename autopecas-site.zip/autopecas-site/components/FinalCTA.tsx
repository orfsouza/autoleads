export default function FinalCTA() {
  return (
    <section
      id="final-cta"
      className="border-t hairline bg-base px-6 py-28 text-center md:px-10"
    >
      <div className="mx-auto max-w-2xl">
        <p className="eyebrow mb-4">chega de ligar de loja em loja</p>
        <h2 className="font-display font-semibold uppercase leading-[0.98] text-4xl sm:text-5xl md:text-6xl">
          Procurar uma peça
          <br />
          nunca foi tão fácil.
        </h2>
        <p className="mt-6 text-lg text-steel">
          Faça seu pedido agora e deixe as lojas virem até você.
        </p>
        <div className="mt-9 flex flex-wrap justify-center gap-4">
          <a
            href="#encontrar"
            className="rounded-full bg-accent px-8 py-4 font-display text-sm font-semibold uppercase tracking-wide text-base transition hover:brightness-110"
          >
            🔍 Encontrar minha peça
          </a>
          <a
            href="#cadastrar-loja"
            className="rounded-full border hairline px-8 py-4 font-display text-sm font-semibold uppercase tracking-wide text-paper transition hover:border-steel"
          >
            🏪 Sou uma autopeça
          </a>
        </div>
      </div>
    </section>
  );
}
