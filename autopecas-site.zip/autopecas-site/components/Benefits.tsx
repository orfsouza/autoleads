const benefits = [
  {
    title: "Economize tempo",
    text: "Um pedido só, em vez de dezenas de ligações.",
  },
  {
    title: "Encontre mais rápido",
    text: "Várias lojas veem sua solicitação ao mesmo tempo.",
  },
  {
    title: "Sem perder horas ao telefone",
    text: "Você espera as lojas te chamarem, não o contrário.",
  },
  {
    title: "Mais chances de achar a peça",
    text: "Quanto mais lojas veem seu pedido, maior a chance de encontrar.",
  },
  {
    title: "Você decide",
    text: "Recebeu mais de uma resposta? Escolha a que for melhor pra você.",
  },
  {
    title: "Feito para o dia a dia",
    text: "Rápido, direto e sem complicação, do jeito que devia ser.",
  },
  {
    title: "Praticidade de verdade",
    text: "Peça de onde estiver, pelo celular ou computador.",
  },
  {
    title: "Foco em te ajudar",
    text: "Nosso trabalho é simples: te ajudar a encontrar a peça o quanto antes.",
  },
];

export default function Benefits() {
  return (
    <section className="border-t hairline bg-surface py-24 px-6 md:px-10">
      <div className="mx-auto max-w-6xl">
        <p className="eyebrow mb-4">benefícios</p>
        <h2 className="font-display font-semibold uppercase text-3xl sm:text-4xl md:text-5xl max-w-xl">
          O que você ganha com isso
        </h2>

        <div className="mt-14 grid gap-px overflow-hidden rounded-2xl border hairline bg-white/5 sm:grid-cols-2 lg:grid-cols-4">
          {benefits.map((b) => (
            <div key={b.title} className="bg-surface p-7">
              <h3 className="font-display text-lg font-semibold uppercase tracking-wide text-paper">
                {b.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-steel">
                {b.text}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
