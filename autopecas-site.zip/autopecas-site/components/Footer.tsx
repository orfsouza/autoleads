export default function Footer() {
  return (
    <footer className="border-t hairline bg-surface px-6 py-12 md:px-10">
      <div className="mx-auto flex max-w-6xl flex-col gap-6 md:flex-row md:items-center md:justify-between">
        <div>
          <p className="font-display text-lg font-semibold uppercase tracking-wide text-paper">
            Peça Certa
          </p>
          <p className="mt-2 max-w-md text-sm text-muted">
            Somos um portal que conecta quem precisa de uma autopeça às
            lojas que podem ter essa peça. Simples, rápido e feito para
            facilitar sua vida.
          </p>
        </div>
        <p className="font-mono text-xs text-muted">
          © {new Date().getFullYear()} Peça Certa. Todos os direitos reservados.
        </p>
      </div>
    </footer>
  );
}
