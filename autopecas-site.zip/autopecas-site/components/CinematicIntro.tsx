"use client";

import { useEffect, useRef, useState } from "react";

/**
 * Bloco cinematic que une Hero + Problema + Solução.
 *
 * Mecânica: a seção tem 500vh de altura. O <video> fica "grudado"
 * (sticky) ocupando a tela inteira enquanto o usuário rola por esses
 * 500vh. A cada pixel de scroll, calculamos o "progresso" (0 a 1) e:
 *   1) setamos video.currentTime = progresso * duração do vídeo
 *      (isso faz o vídeo AVANÇAR conforme o scroll, sem dar play)
 *   2) mostramos/escondemos blocos de texto conforme faixas de progresso
 *
 * Troque o arquivo em /public/videos/hero.mp4 pelo vídeo gerado no Veo3.
 * Recomendado: 1920x1080, 24-30fps, ~20-30s, sem áudio (ou com áudio,
 * ele fica mudo aqui pois o vídeo é só decorativo).
 */

type Stage = {
  from: number; // início da faixa de progresso (0-1)
  to: number; // fim da faixa de progresso (0-1)
  content: React.ReactNode;
};

export default function CinematicIntro() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [progress, setProgress] = useState(0);
  const [videoReady, setVideoReady] = useState(false);

  useEffect(() => {
    let raf = 0;

    function onScroll() {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        raf = 0;
        const section = sectionRef.current;
        if (!section) return;

        const rect = section.getBoundingClientRect();
        const scrollableHeight = section.offsetHeight - window.innerHeight;
        const scrolled = -rect.top;
        const p = Math.min(1, Math.max(0, scrolled / scrollableHeight));
        setProgress(p);

        const video = videoRef.current;
        if (video && video.duration && !Number.isNaN(video.duration)) {
          const target = p * video.duration;
          // evita "tremer" o vídeo com micro-atualizações
          if (Math.abs(video.currentTime - target) > 0.03) {
            video.currentTime = target;
          }
        }
      });
    }

    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => {
      window.removeEventListener("scroll", onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  const stages: Stage[] = [
    {
      from: 0,
      to: 0.22,
      content: (
        <>
          <p className="eyebrow mb-5">peça certa · encontre sua autopeça</p>
          <h1 className="font-display font-semibold uppercase leading-[0.95] text-[13vw] sm:text-6xl md:text-7xl lg:text-8xl tracking-tight">
            Achou a peça.
            <br />
            <span className="text-accent">Sem perder o dia</span>
            <br />
            todo procurando.
          </h1>
          <p className="mt-6 max-w-md text-lg text-steel">
            Você pede a peça uma única vez. As lojas parceiras recebem seu
            pedido e quem tiver, te chama.
          </p>
          <div className="mt-9 flex flex-wrap gap-4">
            <a
              href="#encontrar"
              className="rounded-full bg-accent px-7 py-4 font-display text-sm font-semibold uppercase tracking-wide text-base transition hover:brightness-110"
            >
              🔍 Encontrar minha peça
            </a>
            <a
              href="#cadastrar-loja"
              className="rounded-full border hairline px-7 py-4 font-display text-sm font-semibold uppercase tracking-wide text-paper transition hover:border-steel"
            >
              🏪 Sou uma autopeça
            </a>
          </div>
          <p className="mt-6 text-sm text-muted">
            Um jeito simples e seguro de encontrar a peça certa, sem
            precisar ligar de loja em loja.
          </p>
        </>
      ),
    },
    {
      from: 0.28,
      to: 0.48,
      content: (
        <>
          <p className="eyebrow mb-5">isso já aconteceu com você</p>
          <h2 className="font-display font-semibold uppercase leading-[0.98] text-4xl sm:text-5xl md:text-6xl max-w-2xl">
            O carro quebrou.
            <br />
            E agora, quem tem
            <br />
            a peça?
          </h2>
          <p className="mt-6 max-w-md text-lg text-steel">
            Ligar para uma loja. Depois outra. E mais outra.
            <br />
            Ninguém responde na hora. Ou responde e não tem.
          </p>
          <p className="mt-4 max-w-md text-lg text-steel">
            Passam-se horas. Às vezes, o dia inteiro.
            <br />
            E o carro continua parado.
          </p>
        </>
      ),
    },
    {
      from: 0.54,
      to: 0.78,
      content: (
        <>
          <p className="eyebrow mb-5">agora é diferente</p>
          <h2 className="font-display font-semibold uppercase leading-[0.98] text-4xl sm:text-5xl md:text-6xl max-w-2xl">
            Um pedido só.
            <br />
            <span className="text-gold">Várias lojas</span> vendo.
          </h2>
          <p className="mt-6 max-w-md text-lg text-steel">
            As lojas que trabalham com aquela peça recebem sua solicitação
            na hora. Quem tiver, entra em contato com você.
          </p>
          <p className="mt-4 max-w-md text-lg text-steel">
            Sem ligar para dezenas de lugares. Sem perder tempo.
          </p>
        </>
      ),
    },
    {
      from: 0.84,
      to: 1,
      content: (
        <>
          <p className="eyebrow mb-5">pronto para começar</p>
          <h2 className="font-display font-semibold uppercase leading-[0.98] text-4xl sm:text-5xl md:text-6xl max-w-2xl">
            Simples assim.
            <br />
            Vamos achar sua peça?
          </h2>
          <a
            href="#encontrar"
            className="mt-8 inline-block rounded-full bg-accent px-7 py-4 font-display text-sm font-semibold uppercase tracking-wide text-base transition hover:brightness-110"
          >
            🔍 Encontrar minha peça
          </a>
        </>
      ),
    },
  ];

  return (
    <section ref={sectionRef} className="relative h-[500vh]">
      <div className="sticky top-0 h-screen w-full overflow-hidden bg-base">
        {/* vídeo de fundo, controlado pelo scroll */}
        <video
          ref={videoRef}
          muted
          playsInline
          preload="auto"
          poster="/videos/poster.svg"
          onLoadedMetadata={() => setVideoReady(true)}
          className="absolute inset-0 h-full w-full object-cover opacity-70"
        >
          <source src="/videos/hero.mp4" type="video/mp4" />
        </video>

        {/* fallback visual enquanto o vídeo real (Veo3) não é adicionado */}
        {!videoReady && (
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(255,94,26,0.18),transparent_55%),radial-gradient(circle_at_75%_80%,rgba(232,196,104,0.12),transparent_50%)]" />
        )}

        {/* véu escuro para o texto ficar legível sobre o vídeo */}
        <div className="absolute inset-0 bg-gradient-to-t from-base via-base/70 to-base/30" />
        <div className="grain absolute inset-0" />

        {/* textos em camadas, cada um some/aparece conforme o progresso */}
        <div className="relative z-10 mx-auto flex h-full max-w-6xl items-center px-6 md:px-10">
          {stages.map((stage, i) => {
            const mid = (stage.from + stage.to) / 2;
            const halfSpan = (stage.to - stage.from) / 2;
            const dist = Math.abs(progress - mid) / halfSpan;
            const opacity = Math.max(0, 1 - dist);
            const translate = (1 - opacity) * 24;
            const active = progress >= stage.from && progress <= stage.to;

            return (
              <div
                key={i}
                style={{
                  opacity,
                  transform: `translateY(${translate}px)`,
                  pointerEvents: active ? "auto" : "none",
                }}
                className="absolute inset-x-6 md:inset-x-10 transition-none"
              >
                {stage.content}
              </div>
            );
          })}
        </div>

        {/* indicador de progresso do scroll cinematic */}
        <div className="absolute bottom-8 left-1/2 z-10 h-1 w-40 -translate-x-1/2 overflow-hidden rounded-full bg-white/10">
          <div
            className="h-full bg-accent"
            style={{ width: `${progress * 100}%` }}
          />
        </div>
      </div>
    </section>
  );
}
