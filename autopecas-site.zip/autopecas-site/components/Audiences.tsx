const buyerPoints = [
  "Peça uma vez, em vez de ligar várias vezes",
  "Receba contato de quem realmente tem a peça",
  "Compare e escolha a melhor opção",
  "Economize tempo e energia",
  "Sem custo para procurar",
];

const sellerPoints = [
  "Receba solicitações direto no seu celular",
  "Fale só com quem já quer aquela peça",
  "Sem perder tempo com quem não vai comprar",
  "Mais chances de fechar venda",
  "Cadastro simples e rápido",
];

export default function Audiences() {
  return (
    <section className="border-t hairline bg-base py-24 px-6 md:px-10">
      <div className="mx-auto grid max-w-6xl gap-14 md:grid-cols-2 md:gap-10">
        <div id="encontrar">
          <p className="eyebrow mb-4">para quem procura peças</p>
          <h2 className="font-display font-semibold uppercase text-3xl sm:text-4xl">
            Ache sua peça sem esforço
          </h2>
          <ul className="mt-8 space-y-4">
            {buyerPoints.map((p) => (
              <li key={p} className="flex gap-3 text-steel">
                <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-accent" />
                <span>{p}</span>
              </li>
            ))}
          </ul>
          <a
            href="#final-cta"
            className="mt-9 inline-block rounded-full bg-accent px-7 py-4 font-display text-sm font-semibold uppercase tracking-wide text-base transition hover:brightness-110"
          >
            🔍 Encontrar minha peça
          </a>
        </div>

        <div
          id="cadastrar-loja"
          className="rounded-2xl border hairline bg-surface p-8 md:p-10"
        >
          <p className="eyebrow mb-4">para quem vende peças</p>
          <h2 className="font-display font-semibold uppercase text-3xl sm:text-4xl">
            Venda para quem já quer comprar
          </h2>
          <p className="mt-4 text-steel">
            Sua loja recebe pedidos de pessoas que estão realmente
            procurando comprar. Nada de gente só olhando.
          </p>
          <ul className="mt-8 space-y-4">
            {sellerPoints.map((p) => (
              <li key={p} className="flex gap-3 text-steel">
                <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-gold" />
                <span>{p}</span>
              </li>
            ))}
          </ul>
          <a
            href="#final-cta"
            className="mt-9 inline-block rounded-full border hairline px-7 py-4 font-display text-sm font-semibold uppercase tracking-wide text-paper transition hover:border-steel"
          >
            🏪 Sou uma autopeça
          </a>
        </div>
      </div>
    </section>
  );
}
