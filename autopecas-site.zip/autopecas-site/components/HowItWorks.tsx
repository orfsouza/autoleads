const steps = [
  {
    n: "01",
    title: "Você informa a peça",
    text: "Conte pra gente o que o seu carro precisa. Leva menos de um minuto.",
  },
  {
    n: "02",
    title: "Avisamos as lojas parceiras",
    text: "Sua solicitação chega direto para as autopeças que podem ter essa peça.",
  },
  {
    n: "03",
    title: "Quem tiver, te chama",
    text: "As lojas interessadas entram em contato com você. Você escolhe a melhor opção.",
  },
];

export default function HowItWorks() {
  return (
    <section className="border-t hairline bg-base py-24 px-6 md:px-10">
      <div className="mx-auto max-w-6xl">
        <p className="eyebrow mb-4">como funciona</p>
        <h2 className="font-display font-semibold uppercase text-3xl sm:text-4xl md:text-5xl max-w-xl">
          Três passos. Só isso.
        </h2>

        <div className="mt-16 grid gap-10 md:grid-cols-3 md:gap-6">
          {steps.map((s, i) => (
            <div key={s.n} className="relative">
              <span className="font-mono text-6xl font-medium text-white/10">
                {s.n}
              </span>
              <h3 className="mt-2 font-display text-xl font-semibold uppercase tracking-wide text-paper">
                {s.title}
              </h3>
              <p className="mt-3 max-w-xs text-steel">{s.text}</p>
              {i < steps.length - 1 && (
                <div className="mt-8 hidden h-px w-full bg-gradient-to-r from-white/15 to-transparent md:block" />
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
