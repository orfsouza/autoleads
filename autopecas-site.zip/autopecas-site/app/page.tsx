import CinematicIntro from "@/components/CinematicIntro";
import HowItWorks from "@/components/HowItWorks";
import Benefits from "@/components/Benefits";
import Audiences from "@/components/Audiences";
import FAQ from "@/components/FAQ";
import FinalCTA from "@/components/FinalCTA";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <main>
      {/* Hero + Problema + Solução: vídeo cinematic controlado pelo scroll */}
      <CinematicIntro />

      <HowItWorks />
      <Benefits />
      <Audiences />
      <FAQ />
      <FinalCTA />
      <Footer />
    </main>
  );
}
